# IOT-PPT
Study Material
5th sem- IT
